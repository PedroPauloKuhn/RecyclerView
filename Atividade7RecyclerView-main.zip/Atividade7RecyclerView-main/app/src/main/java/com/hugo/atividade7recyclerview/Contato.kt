package com.hugo.atividade7recyclerview

class Contato (val nome: String, val email: String) {
}